<?php

$nome = $_GET['nome'];
$email = $_GET['email'];

echo "Seu nome é $nome e seu email é $email";